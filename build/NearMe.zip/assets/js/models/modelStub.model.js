/*global _, Backbone*/
define([
	'underscore',
	'backbone'
],
function(UnderscoreLib, BackboneLib) {
	// "use strict";

	return Backbone.Model.extend({
		idAttribute: 'modelId',
		initialize : function() {
			
		}
	});
});