define([
	'underscore',
	'backbone'
],
function(_, Backbone) {
	// "use strict";
	return Backbone.Collection.extend({
		// model: ,
		initialize : function() { }
	});
});