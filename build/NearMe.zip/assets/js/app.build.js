({
    baseUrl: ".",
    name: "nearme-3.0.2",
    out: "nearme-3.0.2.built.js",
	paths : {
		underscore : '../../libs/js/lodash-underscore.min',
		backbone : '../../libs/js/backbone-0.9.2.min',
		jquery : '../../libs/js/jquery-1.7.2.min',
		jqueryMobile : '../../libs/js/jquery.mobile-1.1.0.min',
		googleMaps: '../../libs/js/maps.google'
	}
})