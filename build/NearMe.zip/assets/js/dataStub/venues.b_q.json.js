{
	"root": [
		{
			"id": "4",
			"tradeName": "B&Q",
			"location": {
				"fullAddress": "524 Old Kent Road, SE1 5BA Lond..."
			}
		}, {
			"id": "5",
			"tradeName": "B&Q",
			"location": {
				"fullAddress": "1 Leyton Mills, Marshall Road, E10..."
			}
		}, {
			"id": "6",
			"tradeName": "B&Q",
			"location": {
				"fullAddress": "18 Heybridge Way, Lea Bridge Roa..."
			}
		}
	]
}