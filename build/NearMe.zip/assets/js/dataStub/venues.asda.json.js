{
	"root": [
		{
			"id": "1",
			"tradeName": "Asda Supermarket",
			"location": {
				"fullAddress": "Old Kent Road, SE1 5AG, Ossory..."
			}
		}, {
			"id": "2",
			"tradeName": "Asda Superstore",
			"location": {
				"fullAddress": "151 East Ferry Road, E14 3BT Isle..."
			}
		}, {
			"id": "3",
			"tradeName": "Asda Supermarket",
			"location": {
				"fullAddress": "158 Clapton Common, E5 9AG..."
			}
		}
	]
}